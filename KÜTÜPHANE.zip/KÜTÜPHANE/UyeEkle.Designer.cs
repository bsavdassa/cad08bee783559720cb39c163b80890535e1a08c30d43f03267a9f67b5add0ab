﻿namespace lalal
{
    partial class UyeEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UyeEkle));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTcnumarasi = new System.Windows.Forms.TextBox();
            this.txtKisininadiSoyadi = new System.Windows.Forms.TextBox();
            this.txtyasi = new System.Windows.Forms.TextBox();
            this.txtTelefonu = new System.Windows.Forms.TextBox();
            this.txtAdresi = new System.Windows.Forms.TextBox();
            this.txtkisininepostası = new System.Windows.Forms.TextBox();
            this.txtOkudugukitapsaısı = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cmbKisicinsiyeti = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tc numarası";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Kişinin adı soyadı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(64, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Kişinin yaşı:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Kişinin cinsiyeti:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(80, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telefonu:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(92, 213);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Adresi:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(37, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Kişinin Epostası:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Okduğu kitap sayısı:";
            // 
            // txtTcnumarasi
            // 
            this.txtTcnumarasi.Location = new System.Drawing.Point(168, 55);
            this.txtTcnumarasi.Name = "txtTcnumarasi";
            this.txtTcnumarasi.Size = new System.Drawing.Size(100, 20);
            this.txtTcnumarasi.TabIndex = 8;
            this.txtTcnumarasi.TabStop = false;
            // 
            // txtKisininadiSoyadi
            // 
            this.txtKisininadiSoyadi.Location = new System.Drawing.Point(168, 86);
            this.txtKisininadiSoyadi.Name = "txtKisininadiSoyadi";
            this.txtKisininadiSoyadi.Size = new System.Drawing.Size(100, 20);
            this.txtKisininadiSoyadi.TabIndex = 8;
            // 
            // txtyasi
            // 
            this.txtyasi.Location = new System.Drawing.Point(168, 117);
            this.txtyasi.Name = "txtyasi";
            this.txtyasi.Size = new System.Drawing.Size(100, 20);
            this.txtyasi.TabIndex = 8;
            // 
            // txtTelefonu
            // 
            this.txtTelefonu.Location = new System.Drawing.Point(168, 185);
            this.txtTelefonu.Name = "txtTelefonu";
            this.txtTelefonu.Size = new System.Drawing.Size(100, 20);
            this.txtTelefonu.TabIndex = 8;
            // 
            // txtAdresi
            // 
            this.txtAdresi.Location = new System.Drawing.Point(168, 211);
            this.txtAdresi.Name = "txtAdresi";
            this.txtAdresi.Size = new System.Drawing.Size(100, 20);
            this.txtAdresi.TabIndex = 8;
            // 
            // txtkisininepostası
            // 
            this.txtkisininepostası.Location = new System.Drawing.Point(168, 247);
            this.txtkisininepostası.Name = "txtkisininepostası";
            this.txtkisininepostası.Size = new System.Drawing.Size(100, 20);
            this.txtkisininepostası.TabIndex = 8;
            // 
            // txtOkudugukitapsaısı
            // 
            this.txtOkudugukitapsaısı.Location = new System.Drawing.Point(168, 154);
            this.txtOkudugukitapsaısı.Name = "txtOkudugukitapsaısı";
            this.txtOkudugukitapsaısı.Size = new System.Drawing.Size(100, 20);
            this.txtOkudugukitapsaısı.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(327, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 46);
            this.button1.TabIndex = 9;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(327, 112);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 46);
            this.button2.TabIndex = 10;
            this.button2.Text = "İptal";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmbKisicinsiyeti
            // 
            this.cmbKisicinsiyeti.FormattingEnabled = true;
            this.cmbKisicinsiyeti.Items.AddRange(new object[] {
            "Erkek",
            "Kadın"});
            this.cmbKisicinsiyeti.Location = new System.Drawing.Point(168, 284);
            this.cmbKisicinsiyeti.Name = "cmbKisicinsiyeti";
            this.cmbKisicinsiyeti.Size = new System.Drawing.Size(100, 21);
            this.cmbKisicinsiyeti.TabIndex = 12;
            // 
            // UyeEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.ClientSize = new System.Drawing.Size(591, 376);
            this.Controls.Add(this.cmbKisicinsiyeti);
            this.Controls.Add(this.txtOkudugukitapsaısı);
            this.Controls.Add(this.txtkisininepostası);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtAdresi);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtTelefonu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtyasi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtKisininadiSoyadi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTcnumarasi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UyeEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Üye ekleme işlemleri Sayfası";
            this.Load += new System.EventHandler(this.UyeEkle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTcnumarasi;
        private System.Windows.Forms.TextBox txtKisininadiSoyadi;
        private System.Windows.Forms.TextBox txtyasi;
        private System.Windows.Forms.TextBox txtTelefonu;
        private System.Windows.Forms.TextBox txtAdresi;
        private System.Windows.Forms.TextBox txtkisininepostası;
        private System.Windows.Forms.TextBox txtOkudugukitapsaısı;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbKisicinsiyeti;
    }
}