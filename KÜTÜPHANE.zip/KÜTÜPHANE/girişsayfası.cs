﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lalal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UyeEkle uyeekle = new UyeEkle();
            uyeekle.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UyeListeleme uyelisteleme = new UyeListeleme();
            uyelisteleme.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            KitapEkle kitapekle = new KitapEkle();
            kitapekle.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            KitapListeleme kitaplisteleme = new KitapListeleme();
            kitaplisteleme.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            EmanetKitapVer emanetkitapver = new EmanetKitapVer();
            emanetkitapver.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            EmanetKitapListele emanetkitaplistele = new EmanetKitapListele();
            emanetkitaplistele.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            EmanetKitapİade iade = new EmanetKitapİade();
            iade.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Sıralama sıralama = new Sıralama();
            sıralama.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Grafik grafik = new Grafik();
            grafik.ShowDialog();
        }
    }
}
