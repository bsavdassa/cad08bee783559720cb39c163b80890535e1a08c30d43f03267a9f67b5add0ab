﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lalal
{
    public partial class Sıralama : Form
    {
        public Sıralama()
        {
            InitializeComponent();
        }
        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kutuphane.accdb;Persist Security Info=False;");
        DataSet daset = new DataSet();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

            
        }

        private void Sıralama_Load(object sender, EventArgs e)
        {

            baglanti.Open();
            OleDbDataAdapter adtr = new OleDbDataAdapter("select * from Bilgiler order by okudugukitap desc", baglanti);
            adtr.Fill(daset, "Bilgiler");
            dataGridView1.DataSource = daset.Tables["Bilgiler"];
            baglanti.Close();
            label3.Text = null;
            label4.Text = null;
            label3.Text = daset.Tables["Bilgiler"].Rows[0]["adsoyad"].ToString()+" = ";
        label3.Text+= daset.Tables["Bilgiler"].Rows[0]["okudugukitap"].ToString();
            label4.Text = daset.Tables["Bilgiler"].Rows[dataGridView1.Rows.Count-2]["adsoyad"].ToString()+" = ";
            label4.Text += daset.Tables["Bilgiler"].Rows[dataGridView1.Rows.Count-2]["okudugukitap"].ToString();
        }
    }
}
